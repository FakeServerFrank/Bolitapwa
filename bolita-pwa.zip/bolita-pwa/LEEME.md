# Bolita · PWA

Archivos: `index.html`, `manifest.webmanifest`, `sw.js`, carpeta `icons/` y `vendor/`.

## Cómo publicarla (gratis, necesita HTTPS)
1. **Netlify Drop**: entra a app.netlify.com/drop y arrastra la carpeta `bolita-pwa`.
2. **GitHub Pages**: sube la carpeta a un repositorio y activa Pages.
3. **Cloudflare Pages**: crea un proyecto y sube la carpeta.

Abre la dirección HTTPS en el teléfono. Android muestra "⬇️ Instalar"; en iPhone, Compartir → Añadir a pantalla de inicio.

## Sin internet
- La primera visita debe tener internet (guarda la app y la librería 3D).
- Para no depender de eso, pon `three.min.js` en `vendor/` (ver `vendor/LEEME.txt`).
- Al cambiar el código, sube el número de versión en `sw.js` (`bolita-v1` → `bolita-v2`).

## Amigos sin internet
Conectan por el mismo Wi-Fi o la zona wifi de un teléfono (WebRTC). El Bluetooth necesita una app nativa.
